# GoogleSheetsFront

Сниппет запускает экспорт/импорт с фронта

## Параметры сниппета

| Поле | Описание | Возможные значения. |
| -- | -- |
| id | идентификатор экспорта/импорта | |
| mode | режим работы | export \|\| import \|\| migxExport \|\| migxImport |

## Пример:

	[[!GoogleSheetsFront? 
		&mode = `export`
		&id = 5
	]]