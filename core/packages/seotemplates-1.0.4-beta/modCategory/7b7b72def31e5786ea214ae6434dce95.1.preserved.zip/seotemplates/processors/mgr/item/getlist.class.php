<?php

class seoTemplatesItemGetListProcessor extends modObjectGetListProcessor
{
    public $objectType = 'seoTemplatesItem';
    public $classKey = 'seoTemplatesItem';
    public $defaultSortField = 'id';
    public $defaultSortDirection = 'ASC';
    //public $permission = 'list';


    /**
     * We do a special check of permissions
     * because our objects is not an instances of modAccessibleObject
     *
     * @return boolean|string
     */
    public function beforeQuery()
    {
        if (!$this->checkPermissions()) {
            return $this->modx->lexicon('access_denied');
        }

        return true;
    }


    /**
     * @param xPDOQuery $c
     *
     * @return xPDOQuery
     */
    public function prepareQueryBeforeCount(xPDOQuery $c)
    {
        $query = trim($this->getProperty('query'));
        if ($query) {
            $c->where(array(
                'template:LIKE' => "%{$query}%",
                'OR:field:LIKE' => "%{$query}%",
            ));
        }

        return $c;
    }


    /**
     * @param xPDOObject $object
     *
     * @return array
     */
    public function prepareRow(xPDOObject $object)
    {
        $array = $object->toArray();
        $array['actions'] = array();

        //$mode = $this->getProperty('mode');

        // if ($template = $this->modx->getCollection('modTemplate', array('id:IN' => $array['template']))) {
        //     $array['template'] = array();

        //     foreach($template as $v) {
        //         $array['template'][] = $v->get('templatename');
        //     }
        // }

        if ($field = $this->modx->getObject('seoTemplatesField', $array['field'])) {
            $array['field'] = $field->get('name');
        }
        //$this->modx->log(xPDO::LOG_LEVEL_ERROR, ''.print_r($array, true));

        // Edit
        $array['actions'][] = array(
            'cls' => '',
            'icon' => 'icon icon-edit',
            'title' => $this->modx->lexicon('seotemplates_item_update'),
            //'multiple' => $this->modx->lexicon('seotemplates_items_update'),
            'action' => 'updateItem',
            'button' => true,
            'menu' => true,
        );

        if (!$array['active']) {
            $array['actions'][] = array(
                'cls' => '',
                'icon' => 'icon icon-power-off action-green',
                'title' => $this->modx->lexicon('seotemplates_item_enable'),
                'multiple' => $this->modx->lexicon('seotemplates_items_enable'),
                'action' => 'enableItem',
                'button' => true,
                'menu' => true,
            );
        } else {
            $array['actions'][] = array(
                'cls' => '',
                'icon' => 'icon icon-power-off action-gray',
                'title' => $this->modx->lexicon('seotemplates_item_disable'),
                'multiple' => $this->modx->lexicon('seotemplates_items_disable'),
                'action' => 'disableItem',
                'button' => true,
                'menu' => true,
            );
        }

        // Remove
        $array['actions'][] = array(
            'cls' => '',
            'icon' => 'icon icon-trash-o action-red',
            'title' => $this->modx->lexicon('seotemplates_item_remove'),
            'multiple' => $this->modx->lexicon('seotemplates_items_remove'),
            'action' => 'removeItem',
            'button' => true,
            'menu' => true,
        );

        return $array;
    }

}

return 'seoTemplatesItemGetListProcessor';